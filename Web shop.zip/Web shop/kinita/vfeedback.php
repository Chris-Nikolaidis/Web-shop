<!DOCTYPE html>
<html lang="en">
<?php
	session_start();
	include 'config.php';
	
?>
<head>
	
<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<!-- my additions -->  
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">
  
<!-- slider libraries-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	

<style>
table, th, td {
    border: 1px solid black;
	background-color: #E0FFFF;
    padding: 10px;	
}
</style>
</head>
<body>
	
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> 
		mp3-mp4 & accessories
	</p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
			<li class="active"><a href="#">Home</a></li>
			<li><a href="products.php">Products</a></li>
			<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if($_SESSION['email']=='ro@ot.com'){	
					echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
						<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						<li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νεόυ προϊόντος</a></li>	  
					    <li><a href="vfeedback.php" class="active"><span class="glyphicon glyphicon-plus"></span>View Feedback </a></li>	  
						<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
			?>
			</ul>
		</div>
	</div>
</nav>
<div class="container">    
	<div class="row">
		<div class="col-sm-3">
			
		</div>
		<div class="col-sm-9">
			<?php
			$feed="SELECT * FROM feedback";
			$feedback=$connect->query($feed);
			echo "<table style='width:100%'>
						<tr>
						<th>Ερώτηση1</th>
						<th>Ερώτηση2</th>
						<th>Ερώτηση3</th>
						<th>Ερώτηση4</th>
						<th>Email</th>
						</tr>";
						
						
						if($feedback->num_rows > 0)
						
						{
							while ($row = $feedback->fetch_assoc())
							{
								
								echo " <tr><td>".$row['q1']." </td>
											<td>".$row['q2']." </td>
											<td>".$row['q3']." </td>
											<td>".$row['q4']." </td>
										";
								
								$em=$row['consumer_id'];
								$name="SELECT email FROM consumer WHERE id='$em'";
								$r_name=$connect->query($name);		
								while ($row = $r_name->fetch_assoc())
								{
									echo "<td>".$row['email']."</td>";
								
								}
									echo "</tr>";
										
							}
						}		
			echo "</table>";
			?>
		</div>
	</div>
</div>
<br><br><br>

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>
</body>
</html>