<?php
	session_start();
	include 'config.php';
	
	$model=$_POST['model'];
	$brand=$_POST['brand'];
	$category=$_POST['category'];
	$network=$_POST['network'];
	$launch=$_POST['launch'];
	$device_dimensions=$_POST['device_dimensions'];
	$screen_dimensions=$_POST['screen_dimensions'];
	$screen_pixels=$_POST['screen_pixels'];
	$sim=$_POST['sim'];
	$num_sim=$_POST['num_sim'];
	$os=$_POST['os'];
	$cpu=$_POST['cpu'];
	$ram=$_POST['ram'];
	$card_slot=$_POST['card_slot'];
	$internal_memory=$_POST['internal_memory'];
	$camera_primary=$_POST['camera_primary'];
	$camera_secondary=$_POST['camera_secondary'];
	$radio=$_POST['radio'];
	$wlan=$_POST['wlan'];
	$bluetooth=$_POST['bluetooth'];
	$gps=$_POST['gps'];
	$nfc=$_POST['nfc'];
	$water_proof=$_POST['water_proof'];
	$battery_capacity=$_POST['battery_capacity'];
	$battery_removable=$_POST['battery_removable'];
	$color=$_POST['color'];
	$loud_speaker=$_POST['loud_speaker'];
	$usb=$_POST['usb'];
	$price=$_POST['price'];

	$photo = addslashes(file_get_contents($_FILES['photo']['tmp_name']));

	$sql1 = "SELECT * FROM products ORDER BY id DESC LIMIT 1";
	$result1 = $connect->query($sql1);
	while ($row = $result1->fetch_row()){
		$c= $row[0];
	}
	$c= $c+1;
	$id=$c;
		
	$sql = "INSERT INTO products (id, model, brand, category, network, launch, device_dimensions, screen_dimensions, screen_pixels, sim, num_sim, os, cpu, ram, card_slot, internal_memory, camera_primary, camera_secondary, radio, wlan, bluetooth, gps, nfc, water_proof, battery_capacity, battery_removable, color, loud_speaker, usb, price, photo) VALUES ('".$id."','".$model."','".$brand."','".$category."','".$network."','".$launch."','".$device_dimensions."','".$screen_dimensions."','".$screen_pixels."','".$sim."','".$num_sim."','".$os."','".$cpu."','".$ram."','".$card_slot."','".$internal_memory."','".$camera_primary."','".$camera_secondary."','".$radio."','".$wlan."','".$bluetooth."','".$gps."','".$nfc."','".$water_proof."','".$battery_capacity."','".$battery_removable."','".$color."','".$loud_speaker."','".$usb."','".$price."','".$photo."')";
	$result = $connect->query($sql);
	header( "refresh:3; url=newProduct.php" ); 
	echo 'Επιτυχής εισαγωγή προϊόντος.';
	
?>