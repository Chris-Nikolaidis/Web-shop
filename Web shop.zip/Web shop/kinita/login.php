<!DOCTYPE html>
<html lang="en">
<head>

<title>Log in</title>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- my additions -->
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">

<!-- table style -->
<style>
	table, th, td {
    border: 1px solid black;
	background-color: coral;
    padding: 10px;	
}
</style>
</head>
<body>

<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 </p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php" onClick="home()">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li><a href="homepage.php">Home</a></li>
				<li><a href="products.php">Products</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="active"><a href="login.php"><span class="glyphicon glyphicon-user" name="name"></span> Είσοδος</a></li>
				<li><a href="signup.php"><span class="glyphicon glyphicon-pencil"></span> Εγγραφή</a></li>
		</div>
	</div>
</nav>
	  
<br><br><br><br><br>

<form action="loginAcc.php" method="post" align="center">		
	<table align="center">
		<tr><td>Email</td> <td>   <input name="email" type="text" id="email" required><br></td></tr>
		<tr><td>Password</td> <td>   <input name="password" type="password" id="password" required><br></td></tr>
		<tr><td>Login</td> <td> <button id="login">Log in</button><br></td></tr>
		<tr><td>Reset</td> <td> <input type="button" value="Reset" onClick="window.location.reload()"></td></tr>
	</table>
</form>	  
	  
<br><br><br><br><br>
  
<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>