<?php
	session_start();
	include 'config.php';
	
	$budget = 5000;
	$c_id = $_SESSION['id'];
	$_SESSION['budget1']=0;
	$_SESSION['budget2']=1;
	//echo $budget;
	$sql = "UPDATE basket SET budget='$budget' WHERE consumer_id='$c_id'";
	$result = $connect->query($sql);
	header('Location: http://localhost/kinita/homepage.php');
?>