<!DOCTYPE HTML>

<html lang="en">
<?php
	session_start();
	include 'config.php';
?>
<head>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- my additions -->
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">

<!-- table style -->
<style>
	table, th, td {
    border: 1px solid black;
	background-color: coral;
    padding: 10px;	
}
</style>

</head>
<body>
 
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 & accessories</p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li><a href="homepage.php">Home</a></li>
				<li><a href="products.php">Products</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (isset($_SESSION["name"])){
					if ($_SESSION["email"]== "ro@ot.com"){
						echo '<li class="active"><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root</a></li>
						<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>						
						<<li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νεόυ προϊόντος</a></li>
						<li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
						<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
					else{
						echo '<li class="active"><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
						<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						<li><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
						<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
				}
			?>
			</ul>
		</div>
	</div>
</nav>


<form method="post" action="editprof.php" align="center">

	<table align="center">
		<tr><td>Όνομα </td> <td>  <input name="name"  type="text" id="name" ><br></td></tr>
		<tr><td>Επίθετο </td> <td> <input name="surname" type="text" id="surname" ><br></td></tr>
		<tr><td>Email  </td> <td>  <input name="email" type="email" id="email" ><br></td></tr>
		<tr><td>Διεύθυνση</td> <td> <input name="address" type="text" id="address" ><br></td></tr>
		<tr><td>Τηλέφωνο</td> <td> <input name="phone" type="phone" id="phone" ><br></td></tr>
		<tr><td>Πιστωτική Κάρτα </td> <td>  <input name="credit" type="text" id="credit" ><br></td></tr>
		<tr><td>Κωδικός(Password) </td> <td><input name="password" type="password" id="password" ><br></td></tr>
	</table>
	<p align="center"> Στοιχεία Χρήστη: </p> <br>
	<?php
		$id1=$_SESSION["id"];
		$name1=$_SESSION["name"];
		$surname1=$_SESSION["surname"];
		$email1=$_SESSION["email"];
		$address1=$_SESSION["address"];
		$phone1=$_SESSION["phone"];
		$credit1=$_SESSION["credit_card"];
		$password=$_SESSION["password"];
		echo "<table align='center'>
				<tr>
					<td>Όνομα</td>	<td>" .$name1." </td>
					<td>Επίθετο</td>	<td>" .$surname1." </td>
				</tr>
				<tr>
					<td>Email</td>	<td>" .$email1." </td>
					<td>Διεύθυνση</td>	<td>" .$address1." </td>
				</tr>
				<tr>
					<td>Τηλέφωνο</td>	<td>" .$phone1."  </td>
					<td>Πιστωτική Κάρτα</td>	<td>" .$credit1."  </td>
				</tr>
				<tr>
					<td>Κωδικός</td>	<td>" .$password."  </td>	
				</tr>
			</table>";
	?>
	<br>
	<p align="center"> <button id="e1">Ανανέωση Πληροφοριών</button> </p>
</form>

<br>
<br>
<br>

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>