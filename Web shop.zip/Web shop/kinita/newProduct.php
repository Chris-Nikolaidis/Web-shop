<!DOCTYPE html>
<html lang="en">
<?php
	session_start();
	include 'config.php';
?>

<head>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<!-- my additions -->  
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">

<!-- table style -->
<style>
table, th, td {
    border: 1px solid black;
	background-color: coral;
    padding: 10px;	
}
</style>

</head>
<body>
 
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 </p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php" >TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li ><a href="homepage.php">Home</a></li>
				<li><a href="products.php" >Products</a></li>
				<li><a href="contact.php" >Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if($_SESSION['email']=='ro@ot.com'){	
					echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
					<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
					<li class="active"><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νέου προϊόντος</a></li>
					<li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
					<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
				}	
			?>
			</ul>
		</div>
	</div>
</nav>

			
<form action="add.php" method="post" enctype="multipart/form-data" align="center"> <br>
	<table align="center">
		<tr><td>Model:</td> <td><input type="text" name="model" id="model" required></td></tr>
		<tr><td>Brand:</td> <td><input type="text" name="brand" id="brand" required></td></tr>
		<tr><td>Category:</td> <td>
			<select id="category" name="category" required>
				<option value="phone" id="phone" selected>Phone</option>
				<option value="tablet" id="tablet">Tablet</option>
				<option value="mp3" id="mp3">Mp3</option>
				<option value="mp4"id="mp4" >Mp4</option>
			</select></td></tr>
		<tr><td>Network:</td><td> <input type="text"  name="network"id="network" required></td></tr>
		<tr><td>Launch:</td><td> <input type="text" name="launch" id="launch" required></td></tr>
		<tr><td>Device Dimension</td><td> <input type="text" name="device_dimensions" id="device_dimensions" required></td></tr>
		<tr><td>Screen Dimension</td><td> <input type="number" name="screen_dimensions" id="screen_dimensions" required></td></tr>
		<tr><td>Screen Pixels</td><td> <input type="text" name="screen_pixels" id="screen_pixels" required></td></tr>
		<tr><td>Sim:</td><td> <input type="text" name="sim" id="sim" required></td></tr>
		<tr><td>Num Sim:</td><td>  <input type="number" name="num_sim" id="num_sim" required> </td></tr>
		<tr><td>Os:</td><td> <input type="text" name="os" id="os" required></td></tr>
		<tr><td>Cpu:</td><td> <input type="text" name="cpu" id="cpu" required> </td></tr>
		<tr><td>Ram:</td><td> <input type="text" name="ram" id="ram" required> </td></tr>
		<tr><td>Card Slot:</td><td>  
			<fieldset id="card_slot" name="card_slot" required>
				Yes<input type="radio" value="Yes" name="card_slot" required >
				NO<input type="radio" value="No" name="card_slot" required>
			</fieldset></td></tr>
		<tr><td>Internal Memory:</td><td>  <input type="text" name="internal_memory" id="internal_memory" required> </td></tr>
		<tr><td>Camera Primary:</td><td>  <input type="number" name="camera_primary" id="camera_primary" required> </td></tr>
		<tr><td>Camera Secondary:</td><td>  <input type="number" name="camera_secondary" id="camera_secondary" required> </td></tr>
		<tr><td>Radio:</td><td>  
				<fieldset id="radio" required>
					Yes<input type="radio" value="Yes" name="radio" required> 
					NO<input type="radio" value="No" name="radio" required>
				</fieldset></td></tr>
		<tr><td>Wlan:</td><td> 
				<fieldset id="wlan" required>
					Yes<input type="radio" value="Yes" name="wlan" required >
					NO<input type="radio" value="No" name="wlan" required>
				</fieldset></td></tr>
		<tr><td>Bluetooth:</td><td> 
				<fieldset id="bluetooth" required>
					Yes<input type="radio" value="Yes" name="bluetooth" required>
					NO<input type="radio" value="No" name="bluetooth" required>
				</fieldset></td></tr>
		<tr><td>GPS: </td><td>		
				<fieldset id="gps" required>
					Yes<input type="radio" value="Yes" name="gps" required>
					NO<input type="radio" value="No" name="gps" required>
				</fieldset></td></tr>
		<tr><td>NFC: </td><td>		
				<fieldset id="nfc" required>
					Yes<input type="radio" value="Yes" name="nfc" required>
					NO<input type="radio" value="No" name="nfc" required>
				</fieldset></td></tr>
		<tr><td>Water Proof:</td><td> 
				<fieldset id="water_proof" required>
					Yes<input type="radio" value="Yes" name="water_proof" required>
					NO<input type="radio" value="No" name="water_proof" required>
				</fieldset></td></tr>
		<tr><td>Battery Capacity:</td><td> <input type="text" name="battery_capacity" id="battery_capacity"></td></tr>
		<tr><td>Battery Removable:</td><td> 
				<fieldset  id="battery_removable" required>
					Yes<input type="radio" value="Yes" name="battery_removable" required>
					NO<input type="radio" value="No" name="battery_removable" required>
				</fieldset></td></tr>
		<tr><td>Color:</td><td>  <input type="text" name="color" id="color"></td></tr>
		<tr><td>Loud Speaker:</td><td> <fieldset id="loud_speaker" required>
					Yes<input type="radio" value="Yes" name="loud_speaker" required>
					NO<input type="radio" value="No" name="loud_speaker" required>
				</fieldset></td></tr>
		<tr><td>USB:</td><td> <fieldset id="usb" required>
					Yes<input type="radio" value="Yes" selected name="usb" required>
					NO<input type="radio" value="No" name="usb" required>
				</fieldset></td></tr>
		<tr><td>Price:</td><td> <input type="number" name="price" id="price" required></td></tr>
		<tr><td>Photo:</td><td> <input type="file" name="photo" id="photo" accept="image/*" required></td></tr>
		<tr><td> Υποβολή:</td><td> 	<button name="submit">Submit</button></td></tr>
		<tr><td> Reset:	</td><td> <input type="button" value="Reset" onClick="window.location.reload()"></td></tr>
	</table>
</form>

<br><br><br><br>

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>