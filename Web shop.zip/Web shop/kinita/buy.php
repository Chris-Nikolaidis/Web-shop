<!DOCTYPE html>
<html lang="en">
<?php
	session_start();
	include 'config.php';
	
?>
<head>
	
<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<!-- my additions -->  
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">
<script>
	$(document).ready(function(){
		$(".sel").click(function(){
			$('td[name=money]').val($(this).attr("name"));
			document.getElementByNameTag("qw").submit(); 
		});
	});
</script>
</head>
<body>
	
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> 
		mp3-mp4 & accessories
	</p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
			<li><a href="homepage.php">Home</a></li>
			<li><a href="products.php">Products</a></li>
			<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (!isset($_SESSION["email"])){
					echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Είσοδος</a></li>
						  <li><a href="signup.php"><span class="glyphicon glyphicon-pencil"></span> Εγγραφή</a></li>';
				}
				if (isset($_SESSION['email'])){
					if($_SESSION['email']=='ro@ot.com'){	
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
							  <li class="active"><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νεόυ προϊόντος</a></li>	  
							  <li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
					else{
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
							  <li class="active"><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>'; 
					} 
				}
			?>
			</ul>
		</div>
	</div>
</nav>
<div class="container">    
	<div class="row">
		<div class="col-sm-3">
			<!--carousel-->
		</div>
		<div class="col-sm-9">
			<?php
				$a=$_POST['b2'];
				
				$c_id = $_SESSION["id"];
				$b_id = $_SESSION["basket_id"];
				$stoixeia="SELECT * FROM consumer WHERE id='$c_id'";
				$res=  $connect->query($stoixeia);
				
				echo "<table style='width:100%'>
						<tr>
						<th >Όνομα</th>
						<th>Επίθετο</th>
						<th>Διεύθυνση</th>
						<th>Τρόπος πληρωμής</th>
						<th>Συνολικό Ποσό</th>";
						if($res->num_rows > 0){
							while ($row = $res->fetch_assoc()){
								echo "<tr> <td>".$row['name']." </td>
										<td>".$row['surname']." </td>";
										echo '<form action="fin.php" id="qw" method="post" align="center">';
											echo"<td>";
											if ($_SESSION["address"]=='0') {
												$_SESSION['address1']=1;
												echo '<input name="address" type="text" id="address" required>';
											}
											else {
												$_SESSION['address1']=0;
												echo $row["address"];
											}
											echo "</td>
											<td><select id='payment' name='money' class='sel'>
													<option value='credit' name='money' id='credit' class='sel' selected>Credit Card</option>
													<option value='cash' name='money' id='cash' class='sel'> Cash</option>												
												</select> 
											</td>";
								$total="SELECT * FROM basket WHERE id='$b_id'";
								$res1=  $connect->query($total);
								$_SESSION['t1']=0;
								if($res1->num_rows > 0){
									while ($row = $res1->fetch_assoc()){
										echo   "<td>".$row['total_price']." </td>";
										$_SESSION['t1']=$_SESSION['t1']+$row['total_price'];
									}
								}
							}
						}
						echo "</table>";
				echo "<tr><td><button id='done'>Ολοκλήρωση Παραγγελίας</button></td></tr>";
				echo "</form>";
			?>
		</div>
	</div>
</div>

<br><br><br><br>

<!--<form id="qw" action="fin.php" method="post" hidden>
	<input name="qw1" id="qw1"  />
	<button id="ο3" hidden>run</button><br>
</form> -->

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>
</body>
</html>