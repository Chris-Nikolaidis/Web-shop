<?php
	session_start();
	session_unset();
	header('Location: http://localhost/kinita/homepage.php');
?>