<?php

	session_start();
	include 'config.php';
	
	$budget = $_POST['budget'];
	$c_id = $_SESSION["id"];
	$_SESSION['budget']=$budget;
	$_SESSION['budget1'] =1;
	$_SESSION['budget2']=1;
	if ($budget <1){
		$_SESSION['budget2'] =0;
	}
	//echo $budget;
	$sql = "UPDATE basket SET budget='$budget' WHERE consumer_id='$c_id'";
	$result = $connect->query($sql);
	header('Location: http://localhost/kinita/homepage.php');
?>