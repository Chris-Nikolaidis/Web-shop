<?php 
	$hostname= "localhost";
	$username= "root";
	$password= "";
	$dbname= "kinita";
	$charset= "utf-8";

	$connect = new mysqli($hostname, $username, $password, $dbname);
	if ($connect->connect_error)
	{
		die("Connection failed: " . $conn->connect_error);
	}
?>