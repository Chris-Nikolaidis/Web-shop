<!DOCTYPE html>

<html lang="en">
<?php
	session_start();
	include 'config.php';
?>
<head>

<title>Products</title>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- my additions --> 
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">

<!-- carousel script -->
<script>
	function carousel() {
	var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 3500);
	}
</script>

<!--search script-->
<script>
	$(document).ready(function(){
		$(".img-responsive").click(function(){
			$("#in").val($(this).attr("name"));
			document.getElementById("s1").submit(); 
		});
	});
</script>
	
<style>
.img-responsive{ 
	cursor: pointer; 
}
</style>

</head>
<body>
 
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 </p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li><a href="homepage.php">Home</a></li>
				<li class="active"><a href="products.php">Products</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (!isset($_SESSION["email"])){
					echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Είσοδος</a></li>
						  <li><a href="signup.php"><span class="glyphicon glyphicon-pencil"></span> Εγγραφή</a></li>';
				}
				if (isset($_SESSION['email'])){
					if($_SESSION['email']=='ro@ot.com'){	
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
							<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
							<li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νέου προϊόντος</a></li>
							<li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
							<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
					else{
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
							<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
							<li><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
							<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>'; 
					} 
				}
			?>
			</ul>
		</div>
	</div>
</nav>

<div class="container">    
	<div class="row">
		<div class="col-sm-3">
			<div class="products1" >
				<img class="mySlides" id="car1" style='width:100%' src="photo/phone2.jpg">
				<img class="mySlides" id="car2" style='width:100%' src="photo/tablet.jpg">
				<img class="mySlides" id="car3" style='width:100%' src="photo/1.jpg">		
				<img class="mySlides" id="car4" style='width:100%' src="photo/2.jpg">
				<img class="mySlides" id="car5" style='width:100%' src="photo/4.jpg">
				<img class="mySlides" id="car6" style='width:100%' src="photo/6.jpg">
				<img class="mySlides" id="car7" style='width:100%' src="photo/7.jpg">
				<img class="mySlides" id="car8" style='width:100%' src="photo/8.jpg">
				<img class="mySlides" id="car9" style='width:100%' src="photo/13.jpg">
				<img class="mySlides" id="car10" style='width:100%' src="photo/15.jpg">				
			</div>
			<script>
				var myIndex = 0;
				carousel();
			</script>
		</div> 
		<div class="col-sm-9">
			<div class="row">
				<div class="col-sm-4 cat1">
					<div class="panel panel-primary">
						<div class="panel-heading">Τηλέφωνα</div>
						<div class="panel-body"> <img src="photo/phone.jpg" class="img-responsive" name="1" style="width:100%" alt="Image"> </div>
						<div class="panel-footer">Όλα τα κινητά τηλέφωνα</div>
					</div>
				</div>
				<div class="col-sm-4 cat2"> 
					<div class="panel panel-danger">
						<div class="panel-heading">Tablet</div>
						<div class="panel-body"> <img src="photo/ipads.jpg" class="img-responsive" name="2" style="width:100%" alt="Image">  </div>
						<div class="panel-footer">Όλα τα tablet & tablet κινητά</div>
					</div>
				</div>
				<div class="col-sm-4 cat3"> 
					<div class="panel panel-success">
						<div class="panel-heading">MP3s</div>
						<div class="panel-body"><img src="photo/18.jpg" class="img-responsive" name="3" style="width:100%" alt="Image"></div>
						<div class="panel-footer">Μουσική</div>
					</div>
				</div>
			</div>	
			<br>
			<div class="row">
				<div class="col-sm-4 cat4">
					<div class="panel panel-primary">
						<div class="panel-heading">MP4s</div>
						<div class="panel-body"><img src="photo/12.jpg" class="img-responsive" name="4" style="width:100%" alt="Image"></div>
						<div class="panel-footer">Μουσική και video </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<br><br>
<form id="s1" action="psearch.php" method="post" hidden>
	<input name="in" id="in" />
	<button >run</button><br>
</form>
<br>
<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>
