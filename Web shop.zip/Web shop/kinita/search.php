<?php
session_start();
	include 'config.php';

$model = $_POST['model'];

//Autes tis times tis xrisimopoiw gia na elegxw poies katigories exoun epilexthei
if(isset($_POST['phone'])){
    $phone = $_POST['phone'];
}
else{
    $phone = 1;//default value
}
if(isset($_POST['tablet'])){
    $tablet = $_POST['tablet'];
}
else{
    $tablet = 1;//default value
}
if(isset($_POST['mp3'])){
    $mp3 = $_POST['mp3'];
}
else{
    $mp3 = 1;//default value
}
if(isset($_POST['mp4'])){
    $mp4 = $_POST['mp4'];
}
else{
    $mp4 = 1;//default value
}

//search me euros timwn
$min=$_POST['min1'];
$max=$_POST['max1'];

//search ana katigoria, exontas dwsei montelo
if($model!=''){
	if($phone==1 && $tablet==1 && $mp3==1 && $mp4==1){//kamia katigoria epilegmeni.
		$check= "SELECT * FROM products WHERE (price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
	}
	else{
		if($phone!=1){//phone
			$check= "SELECT * FROM products WHERE  (category = '$phone' AND(price>= '$min') AND price<= '$max') AND model LIKE '%$model%'";	
			if($tablet!=1){//phone + tablet
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($mp3!=1){//phone + mp3
				$check= "SELECT * FROM products WHERE  (category = '$phone' OR category = '$mp3') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($mp4!=1){//phone + mp4
				$check= "SELECT * FROM products WHERE  (category = '$phone' OR category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}	
		}
		if($tablet!=1){//tablet
			$check= "SELECT * FROM products WHERE  category = '$tablet' AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";	
			if($phone!=1){// tablet + phone 
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($mp3!=1){//tablet + mp3
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp3') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($mp4!=1){//tablet + mp4
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}	
		}
		if($mp3!=1){//mp3
			$check= "SELECT * FROM products WHERE  category = '$mp3' AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";	
			if($phone!=1){// mp3 + phone 
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($tablet!=1){//mp3 + tablet
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp3') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($mp4!=1){//mp3 + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}	
		}
		if($mp4!=1){//mp4
			$check= "SELECT * FROM products WHERE  (category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			if($phone!=1){// mp4 + phone 
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($tablet!=1){//mp4 + tablet
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($mp3!=1){//mp4 + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}	
		}
		if($phone!=1){
			if($mp3!=1 && $mp4!=1){//phone + mp3 + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max') ANDmodel LIKE '%$model%'";
			}
			if($tablet!=1 && $mp3!=1){//phone + tablet + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($tablet!=1 && $mp4!=1){//phone + tablet + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
		}
		if($tablet!=1){
			if($mp3!=1 && $mp4!=1){//tablet + mp3 + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$tablet') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($phone!=1 && $mp3!=1){//tablet + mp3 + phone
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($phone!=1 && $mp4!=1){//tablet + phone + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
		}
		if($mp3!=1){
			if($phone!=1 && $mp4!=1){//mp3 + mp4 + phone
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($phone!=1 && $tablet!=1){//mp3 + phone + tablet
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($tablet!=1 && $mp4!=1){//mp3 + tablet + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$mp4') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
		}
		if($mp4!=1){
			if($phone!=1 && $mp3!=1){//mp4 + phone + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($phone!=1 && $tablet!=1){//mp4 + phone + tablet
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
			if($tablet!=1 && $mp3!=1){//mp4 + tablet + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$mp3') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
			}
		}
	}		
		
	if($phone=='phone' && $tablet=='tablet' && $mp3=='mp3' && $mp4=='mp4'){//an exei epileksei oles tis katigories
		$check= "SELECT * FROM products WHERE (category = '$mp4' OR category = '$tablet' OR category = '$mp3' OR category = '$phone') AND(price>= '$min' AND price<= '$max') AND model LIKE '%$model%'";
	}
}	
else{//search ana katigoria, xwris na exei dwsei montelo
	if($phone==1 && $tablet==1 && $mp3==1 && $mp4==1){//kamia katigoria epilegmeni.
		$check= "SELECT * FROM products WHERE  price>= '$min' AND price<= '$max'";
	}
	else{
		if($phone!=1){//phone
			$check= "SELECT * FROM products WHERE  (category = '$phone' AND(price>= '$min') AND price<= '$max')";	
			if($tablet!=1){//phone + tablet
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($mp3!=1){//phone + mp3
				$check= "SELECT * FROM products WHERE  (category = '$phone' OR category = '$mp3') AND(price>= '$min' AND price<= '$max')";
			}
			if($mp4!=1){//phone + mp4
				$check= "SELECT * FROM products WHERE  (category = '$phone' OR category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			}	
		}
		if($tablet!=1){//tablet
			$check= "SELECT * FROM products WHERE  category = '$tablet' AND(price>= '$min' AND price<= '$max')";	
			if($phone!=1){// tablet + phone 
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($mp3!=1){//tablet + mp3
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp3') AND(price>= '$min' AND price<= '$max')";
			}
			if($mp4!=1){//tablet + mp4
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			}	
		}
		if($mp3!=1){//mp3
			$check= "SELECT * FROM products WHERE  category = '$mp3' AND(price>= '$min' AND price<= '$max')";
			if($phone!=1){// mp3 + phone 
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($tablet!=1){//mp3 + tablet
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp3') AND(price>= '$min' AND price<= '$max')";
			}
			if($mp4!=1){//mp3 + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			}	
		}
		if($mp4!=1){//mp4
			$check= "SELECT * FROM products WHERE  (category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			if($phone!=1){// mp4 + phone 
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($tablet!=1){//mp4 + tablet
				$check= "SELECT * FROM products WHERE  (category = '$tablet' OR category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			}
			if($mp3!=1){//mp4 + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			}	
		}
		if($phone!=1){
			if($mp3!=1 && $mp4!=1){//phone + mp3 + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($tablet!=1 && $mp3!=1){//phone + tablet + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($tablet!=1 && $mp4!=1){//phone + tablet + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
		}
		if($tablet!=1){
			if($mp3!=1 && $mp4!=1){//tablet + mp3 + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$tablet') AND(price>= '$min' AND price<= '$max')";
			}
			if($phone!=1 && $mp3!=1){//tablet + mp3 + phone
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($phone!=1 && $mp4!=1){//tablet + phone + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
		}
		if($mp3!=1){
			if($phone!=1 && $mp4!=1){//mp3 + mp4 + phone
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($phone!=1 && $tablet!=1){//mp3 + phone + tablet
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($tablet!=1 && $mp4!=1){//mp3 + tablet + mp4
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$tablet' OR category = '$mp4') AND(price>= '$min' AND price<= '$max')";
			}
		}
		if($mp4!=1){
			if($phone!=1 && $mp3!=1){//mp4 + phone + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp3' OR category = '$mp4' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($phone!=1 && $tablet!=1){//mp4 + phone + tablet
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$phone') AND(price>= '$min' AND price<= '$max')";
			}
			if($tablet!=1 && $mp3!=1){//mp4 + tablet + mp3
				$check= "SELECT * FROM products WHERE  (category = '$mp4' OR category = '$tablet' OR category = '$mp3') AND(price>= '$min' AND price<= '$max')";
			}
		}
	}		
	if($phone=='phone' && $tablet=='tablet' && $mp3=='mp3' && $mp4=='mp4'){//an exei epileksei oles tis katigories
		$check= "SELECT * FROM products WHERE (category = '$mp4' OR category = '$tablet' OR category = '$mp3' OR category = '$phone') AND(price>= '$min' AND price<= '$max') ";
	}
}

//teliki emfanisi
$_SESSION["tel"] = $check;
header('Location: http://localhost/kinita/search_res.php');	

?>