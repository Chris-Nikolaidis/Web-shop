<?php 
session_start();
include 'config.php';

$email= $_POST['email'];
$password= $_POST['password'];

$sql = "SELECT * FROM consumer WHERE email = '$email' and password = '$password'";
$result = $connect->query($sql);
if ( $result->num_rows > 0 ){
	while($row = $result->fetch_assoc()){
		$id = $row["id"];
		$name = $row["name"];
		$surname = $row["surname"];
		$email = $row["email"];
		$address = $row["address"];
		$phone = $row ["phone"];
		$credit_card = $row["credit_card"];
		$password = $row["password"];
	}
	$_SESSION["id"] = $id;
	$_SESSION["name"] = $name;
	$_SESSION["surname"] = $surname;
	$_SESSION["email"] = $email;
	$_SESSION["address"] = $address;
	$_SESSION["phone"] = $phone;
	$_SESSION["credit_card"] = $credit_card;
	$_SESSION["password"] = $password;

	$sql = "SELECT * FROM basket WHERE consumer_id = '$id'";
	$result = $connect->query($sql);
	if ( $result->num_rows > 0 ){
		while($row = $result->fetch_assoc()) {
			$id1 = $row["id"];
			$_SESSION["basket_id"] = $id1;
		}
	}
	$_SESSION['budget1']=0;
	echo 'Επιτυχής σύνδεση στο σύστημα.';
	header('Location: http://localhost/kinita/homepage.php');
}
else{
	echo 'Το email ή ο κωδικός που δώσατε, είναι λάθος. Προσπαθήστε ξανά.';
	header('Location: http://localhost/kinita/login.php');
}

?>