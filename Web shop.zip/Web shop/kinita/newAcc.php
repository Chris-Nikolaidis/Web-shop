<?php
session_start();
include 'config.php';

$name=$_POST['name'];
$surname=$_POST['surname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$password=$_POST['password'];
$id;

$check= "SELECT * FROM consumer WHERE email = '$email'";
$check1=$connect->query($check);
		
if( $check1->num_rows > 0 ){
	header( "refresh:3; url=signup.php" );
	echo "Υπάρχει ήδη χρήστης με αυτό το email.";
}
else{
	$sql = "SELECT name FROM consumer";
	$result = $connect->query($sql);
	$c=$result->num_rows;
	$c++;
	$id=$c;
	$address = 0;
	$credit = 0;
	$sql="INSERT into consumer (id,name,surname,email,address,phone,credit_card,password) VALUES('".$id."','".$name."','".$surname."','".$email."','".$address."','".$phone."','".$credit."','".$password."')";
	$result = $connect->query($sql);
	$b= "SELECT id FROM basket";
	$res = $connect->query($b);
	$c1=$res->num_rows;
	$c1++;
	$id1=$c1;
	$total_price=0;
	$budget=5000;
	$basket="INSERT into basket (id,consumer_id,total_price,budget) VALUES ('".$id1."','".$id."','".$total_price."','".$budget."')";
	//session id
	$_SESSION["basket_id"] = $id1;
	$bas = $connect->query($basket);
	header( "refresh:3; url=homepage.php" );
	echo "Account created successfully";
}

?> 