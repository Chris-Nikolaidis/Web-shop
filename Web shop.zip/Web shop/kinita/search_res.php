<!DOCTYPE html>
<html lang="en">
<?php
	session_start();
	include 'config.php';
?>
<head>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- my additions -->
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">
  
<!-- slider libraries-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
	$(document).ready(function(){
		$(".selecter").click(function(){
			$("#lol").val($(this).attr("name"));
			document.getElementById("q").submit(); 
		});
	});
</script>

<script>
	$(document).ready(function(){
		$(".selecter1").click(function(){
			$("#lol2").val($(this).attr("name"));
			document.getElementById("d").submit(); 
		});
	});
</script>

<script>
	$(document).ready(function(){
		$(".selecter2").click(function(){
			$("#lol3").val($(this).attr("name"));
			document.getElementById("p").submit(); 
		});
	});
</script>

<script>
  $( function() { 
    $( "#slider-range" ).slider({
      range: true,
      min: 0,
     max:  5000,
      values: [ 0, 5000 ],
      slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
		$("#min1").val(ui.values[ 0 ]);
                    $("#max1").val(ui.values[ 1 ]);
      }
    });
    $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
      " - $" + $( "#slider-range" ).slider( "values", 1 ) ); 
  } );
</script>

<style>
#lol, #lol2, #lol3 {
	size: 20%;
	display: none;
}
table, th, td {
    border: 1px solid black;
	background-color: coral;
}
#but1{
  padding: 3px 3px;
  font-size: 18px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 3px;
  box-shadow: 0 9px #999;
}

#but1:hover {
	background-color: #3e8e41
}

#but1:active {
  background-color: #3e8e41;
  box-shadow: 0 3px #666;
  transform: translateY(4px);
}
</style>

</head>
<body>

<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 & accessories</p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li><a href="homepage.php">Home</a></li>
				<li class="active"><a href="products.php">Products</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (isset($_SESSION["email"])){
					if($_SESSION['email']=='ro@ot.com'){	
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
							  <li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νεόυ προϊόντος</a></li>	  
							  <li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
					else{
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
							  <li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>'; 
					} 
				} 
				if (!isset($_SESSION["email"])){
					echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Είσοδος</a></li>
						  <li><a href="signup.php"><span class="glyphicon glyphicon-pencil"></span> Εγγραφή</a></li>';
				}	
			?>
			</ul>
		</div>
	</div>
</nav>
<div class="container">    
	<div class="row">
		<div class="col-sm-3">
			<?php
				if (isset($_SESSION["email"])){
					echo '<form action="budget.php" method="post">
						   Άμα επιθυμείτε, μπορείτε να θέσετε το budget σας.<br>
						   Budget<input type="number" min="1" name="budget" id="budget"><br>
						   <button id="add_budget">Add Budget</button><br>
						   </form>';
				}
				if (isset($_SESSION['budget1'])){
					if ($_SESSION['budget1']==1){
						echo'<form action="budget1.php" method="post">
							<button id="add_budget1">Remove budget</button><br>
							</form>';
						echo'<form action="search.php" method="post">';
						echo'<input type="number" name="max1" id="max1" max="'.$_SESSION['budget'].'" value="'.$_SESSION['budget'].'" onkeydown="return false"/>
							<input type="number" name="min1" id="min1" max="'.$_SESSION['budget'].'" value="0" onkeydown="return false"/>';
						echo '<tr> <br>
							Αναζήτηση με βάση το μοντέλο: 
							<input name="model" type="text" value="" id="model" >
							<br>
							<input type="checkbox" name="phone" id="phone" value="phone"> phone<br>
							<input type="checkbox" name="tablet" id="tablet" value="tablet"> tablet<br>
							<input type="checkbox" name="mp3" id="mp3" value="mp3"> mp3<br>
							<input type="checkbox" name="mp4" id="mp4" value="mp4"> mp4<br>
		
							<button id="search">search</button><br>
							</form>';
					}
					else {
						echo '<form action="search.php" method="post">
						<div id="slider"> </div>
						<p>
						<label for="amount">Price range:</label>
						<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
						</p>
						<div id="slider-range"></div>
						<br>
						<input type="hidden" name="min1" id="min1" value="0"/>
						<input type="hidden" name="max1" id="max1" value="5000"/>
						<tr>
						Αναζήτηση με βάση το μοντέλο: 
						<input name="model" type="text" value="" id="model" >
						<br>
						<input type="checkbox" name="phone" id="phone" value="phone"> phone<br>
						<input type="checkbox" name="tablet" id="tablet" value="tablet"> tablet<br>
						<input type="checkbox" name="mp3" id="mp3" value="mp3"> mp3<br>
						<input type="checkbox" name="mp4" id="mp4" value="mp4"> mp4<br>
						<button id="search">search</button><br>
						</form>';
					}
				}
				else {
					echo '<form action="search.php" method="post">
						<div id="slider"> </div>
						<p>
						<label for="amount">Price range:</label>
						<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
						</p>
						<div id="slider-range"></div>
						<br>
						<input type="hidden" name="min1" id="min1" value="0"/>
						<input type="hidden" name="max1" id="max1" value="5000"/>
						<tr>
						Αναζήτηση με βάση το μοντέλο: 
						<input name="model" type="text" value="" id="model" >
						<br>
						<input type="checkbox" name="phone" id="phone" value="phone"> phone<br>
						<input type="checkbox" name="tablet" id="tablet" value="tablet"> tablet<br>
						<input type="checkbox" name="mp3" id="mp3" value="mp3"> mp3<br>
						<input type="checkbox" name="mp4" id="mp4" value="mp4"> mp4<br>
						<button id="search">search</button><br>
						</form>';
				}
			?>	
		</div>
		<div class="col-sm-9">
			<form id="q" action="search1.php" method="post">
				<input name="lol" id="lol" onchange="run()" />
				<button id="search" hidden>run</button><br>
			</form>
			<form id="d" action="basket.php" method="post">
				<input name="lol2" id="lol2" onchange="run()" />
				<button id="search" hidden>run</button><br>
			</form>
			<form id="p" action="del_pr.php" method="post">
				<input name="lol3" id="lol3" onchange="run()" />
				<button id="search" hidden>run</button><br>
			</form>
			<?php
				$query = $_SESSION["tel"];
				$result = $connect->query($query);
				echo "<table style='width:100%'> <tr>
						<th style='width:18%'>Image</th>
						<th>Model</th>
						<th>Brand</th>
						<th>Category</th>
						<th>Color</th>
						<th>Price</th>
						<th style='width:15%'> Add To Cart </th>"; 
							if (isset($_SESSION["email"])){
								if ($_SESSION["email"]=='ro@ot.com'){
									echo "<th style='width:15%'> Delete Product </th>";
								}
							}								
						echo "</th>";
				if($result->num_rows > 0){
					$product_item=array();
					$index=0;
					while ($row = $result->fetch_assoc()){
						$product_item[]= $row;
						echo "<tr> <td> <div name='". $product_item[$index]['id'] . "'class='selecter'>". '<img style="width:100%" src="data:image/jpeg;base64,'.base64_encode( $product_item[$index]['photo'] ).'"/>'."</div></td>
							<td> <div name='". $product_item[$index]['id'] . "' class='selecter'>". $product_item[$index]['model']."</div></td>
							<td> <div name='". $product_item[$index]['id'] . "' class='selecter'>". $product_item[$index]['brand']."</div></td>
							<td> <div name='". $product_item[$index]['id'] . "' class='selecter'>". $product_item[$index]['category']."</div></td>
							<td> <div name='". $product_item[$index]['id'] . "' class='selecter'>". $product_item[$index]['color']."</div></td>
							<td> <div name='". $product_item[$index]['id'] . "' class='selecter'>". $product_item[$index]['price']."</div></td>";
						    if (isset($_SESSION["email"])){
								if ($_SESSION['budget1']==1){
									$price2 = $product_item[$index]['price'];
									$budget2 = $_SESSION['budget'];
									if ($price2 > $budget2) {
										echo "<td> Add more budget to buy it</td>";
									}
									else {
										echo "<td> <div name='". $product_item[$index]['id'] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div></td>";
									}
								}
								else {
									echo "<td> <div name='". $product_item[$index]['id'] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div></td>";
								}
								if ($_SESSION["email"]=='ro@ot.com'){
									echo "<td> <div name='". $product_item[$index]['id'] . "' class='selecter2'><button id='but1' class='glyphicon glyphicon-remove'>Delete product</button></div></td>";
								} 
						    }
						    echo "<tr>";
						$index = $index +1;
					}
				}
			echo "</table>";
			?>
		</div>
	</div>
</div>

<br><br><br>

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>