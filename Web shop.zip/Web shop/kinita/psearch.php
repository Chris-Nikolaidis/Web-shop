<?php
	session_start();
	include 'config.php';
	$a=$_POST['in'];
	
if($a==1){ //phone
	$check= "SELECT * FROM products WHERE  category = 'phone' ";
}
if($a==2){//tablet
	$check= "SELECT * FROM products WHERE  category = 'tablet' ";
}
if($a==3){//mp3
	$check= "SELECT * FROM products WHERE  category = 'mp3' ";
}
if($a==4){//mp4
	$check= "SELECT * FROM products WHERE  category = 'mp4' ";
}

$_SESSION["tel"] = $check;
header('Location: http://localhost/kinita/search_res.php');

?>