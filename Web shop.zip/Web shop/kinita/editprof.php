<?php
session_start();
include 'config.php';
$cd=$_SESSION["id"];
$name=$_POST['name'];
$surname=$_POST['surname'];
$email=$_POST['email'];
$address=$_POST['address'];
$phone=$_POST['phone'];
$credit=$_POST['credit'];
$password=$_POST['password'];
//checkarw poia stoixeia exoun eisaxthei
//check an exei mpei neo email

if($email!=NULL){
	$check="SELECT * FROM consumer WHERE email = '$email'";
	$check1=$connect->query($check);
	
	//check an to neo email yparxei stin basi
	if( $check1->num_rows > 0 ){
		echo "Αυτό το email χρησιμοποιείται ήδη.";
		header('Location: http://localhost/kinita/editprofile.php');
	}
	//an den yparxei, proxwrw stin allagi twn stoixeiwn
	else{
		//checkarw poia stoixeia exoun eisaxthei
		if($name!=NULL){
			$up= "UPDATE consumer SET name='$name' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["name"] = $name;
		}
		if($surname!=NULL){
			$up= "UPDATE consumer SET surname='$surname' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["surname"] = $surname;
		}
		if($email!=NULL){
			$up= "UPDATE consumer SET email='$email' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["email"] = $email;
		}
		if($address!=NULL){
			$up= "UPDATE consumer SET address='$address' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["address"] = $address;
		}
		if($phone!=NULL){
			$up= "UPDATE consumer SET phone='$phone' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["phone"] = $phone;
		}
		if($credit!=NULL){
			$up= "UPDATE consumer SET credit_card='$credit' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["credit_card"] = $credit;
		}
		if($password!=NULL){
			$up= "UPDATE consumer SET password='$password' WHERE id='$cd'";
			$op=$connect->query($up);
			$_SESSION["password"] = $password;
		}
		header('Location: http://localhost/kinita/editprofile.php');
	}
}
else{
	//checkarw poia stoixeia exoun eisaxthei
	if($name!=NULL){
		$up= "UPDATE consumer SET name='$name' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["name"] = $name;
	}
	if($surname!=NULL){
		$up= "UPDATE consumer SET surname='$surname' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["surname"] = $surname;
	}
	if($email!=NULL){
		$up= "UPDATE consumer SET email='$email' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["email"] = $email;
	}
	if($address!=NULL){
		$up= "UPDATE consumer SET address='$address' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["address"] = $address;
	}
	if($phone!=NULL){
		$up= "UPDATE consumer SET phone='$phone' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["phone"] = $phone;
	}
	if($credit!=NULL){
		$up= "UPDATE consumer SET credit_card='$credit' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["credit_card"] = $credit;
	}
	if($password!=NULL){
		$up= "UPDATE consumer SET password='$password' WHERE id='$cd'";
		$op=$connect->query($up);
		$_SESSION["password"] = $password;
	}	
	header('Location: http://localhost/kinita/editprofile.php');
}
?>