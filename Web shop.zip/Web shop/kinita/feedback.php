<!DOCTYPE html>

<html lang="en">
<?php
	session_start();
	include 'config.php';
?>

<head>
<title>Feedback</title>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<!-- my additions -->  
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">
  
<!-- table style -->
<style>
	table, th, td {
    border: 1px solid black;
	background-color: #E0FFFF;
    padding: 10px;	
	width: 100%;
}
</style>

</head>
<body>
 
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 </p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php" onClick="home()">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li ><a href="homepage.php">Home</a></li>
				<li><a href="products.php" >Products</a></li>
				<li><a href="contact.php" >Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (isset($_SESSION['email'])){
					echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
						<li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						<li  class="active"><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
						<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';	
				}
			?>
			</ul>
		</div>
	</div>
</nav>

<form action="feed.php" method="post" align="center">
	<table align="center">
		<tr><td>Ερώτηση 1: Πόσο ευχαριστημένος/η είσαστε από την ιστοσελίδα;</td> <td>
				<input type="radio" name="q1" value="1" > Καθόλου <br>
				<input type="radio" name="q1" value="2" > Λίγο<br>
				<input type="radio" name="q1" value="3" checked> Έτσι και Έτσι <br>
				<input type="radio" name="q1" value="4" > Αρκετά <br>
				<input type="radio" name="q1" value="5" > Τέλειο <br></td></tr>

		<tr><td>Ερώτηση 2: Βρίσκετε ό,τι επιθυμείτε σε ανταγωνιστικές τιμές;</td> <td>
				<input type="radio" name="q2" value="1"> Καθόλου <br>
				<input type="radio" name="q2" value="2"> Λίγο<br>
				<input type="radio" name="q2" value="3" checked > Έτσι και Έτσι <br>
				<input type="radio" name="q2" value="4"> Αρκετά <br>
				<input type="radio" name="q2" value="5"> Τέλειο <br></td></tr>


		<tr><td>Ερώτηση 3: Η ταχύτητα απόκρισης της ιστοσελίδας είναι ικανοποιητική;</td> <td>
				<input type="radio" name="q3" value="1"> Καθόλου <br>
				<input type="radio" name="q3" value="2"> Λίγο<br>
				<input type="radio" name="q3" value="3" checked > Έτσι και Έτσι <br>
				<input type="radio" name="q3" value="4"> Αρκετά <br>
				<input type="radio" name="q3" value="5"> Τέλειο <br></td></tr>


		<tr><td>Ερώτηση 4: Πείτε μας με λίγα λόγια τι μελλοντικές αλλαγές θα επιθυμούσατε να δείτε στην ιστοσελίδα.</td> <td>
		<div>
			<textarea rows="4" cols="50" name="q4" value="Apantisi" placeholder="Εισάγεται την άποψη σας" required></textarea>
		</div>  </td></tr>
		<tr><td>Υποβολή</td><td><button>Submit</button><br></td></tr>
		<tr><td>Reset</td><td><input type="button" value="Reset" onClick="window.location.reload()"></td></tr>
	</table>
</form>

<br><br><br>

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>