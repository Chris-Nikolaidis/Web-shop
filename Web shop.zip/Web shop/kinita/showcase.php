<!DOCTYPE html>
<html lang="en">
<?php
	session_start();
	include 'config.php';
?>
<head>

<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- my additions -->  
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">

<!-- slider libraries-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<style>
#lol2, #lol3 {
	display: none;
}
.row1 {
	border: 1px solid black;
	background-color: coral;
	padding: 3px;
}
.row2 {
	border: 1px solid black;
	background-color: white;
	padding: 1px;
}
#but1{
  padding: 3px 3px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 3px;
  box-shadow: 0 9px #999;
}

#but1:hover {
	background-color: #3e8e41
}

#but1:active {
  background-color: #3e8e41;
  box-shadow: 0 3px #666;
  transform: translateY(4px);
}
</style>

<script>
	$(document).ready(function(){
		$(".selecter1").click(function(){
			$("#lol2").val($(this).attr("name"));
			document.getElementById("d").submit(); 
		});
	});
</script>

<script>
	$(document).ready(function(){
		$(".selecter2").click(function(){
			$("#lol3").val($(this).attr("name"));
			document.getElementById("p").submit(); 
		});
	});
</script>

<!-- slider -->
<script>
  $( function() { 
    $( "#slider-range" ).slider({
      range: true,
      min: 0,
     max:  5000,
      values: [ 0, 5000 ],
      slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
		$("#min1").val(ui.values[ 0 ]);
                    $("#max1").val(ui.values[ 1 ]);
      }
    });
    $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
      " - $" + $( "#slider-range" ).slider( "values", 1 ) ); 
  } );
</script>
</head>
<body>
	
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> mp3-mp4 & accessories</p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li><a href="homepage.php">Home</a></li>
				<li class="active"><a href="products.php">Products</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (!isset($_SESSION["email"])){
					echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Είσοδος</a></li>
						  <li><a href="signup.php"><span class="glyphicon glyphicon-pencil"></span> Εγγραφή</a></li>';
				}
				if (isset($_SESSION['email'])){
					if($_SESSION['email']=='ro@ot.com'){	
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
							  <li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νεόυ προϊόντος</a></li>	  
							  <li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
					else{
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
							  <li><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>'; 
					} 
				}
			?>
			</ul>
		</div>
	</div>
</nav>
<div class="container">    
	<div class="row">
		<div class="col-sm-3">
			<?php
				if (isset($_SESSION["email"])){
					echo '<form action="budget.php" method="post">
						   Άμα επιθυμείτε, μπορείτε να θέσετε το budget σας.<br>
						   Budget<input type="number" min="1" name="budget" id="budget"><br>
						   <button id="add_budget">Add Budget</button><br>
						   </form>';
				}
				if (isset($_SESSION['budget1'])){
					if ($_SESSION['budget1']==1){
						echo'<form action="budget1.php" method="post">
							<button id="add_budget1">Remove budget</button><br>
							</form>';
						echo'<form action="search.php" method="post">';
						echo'<input type="number" name="max1" id="max1" max="'.$_SESSION['budget'].'" value="'.$_SESSION['budget'].'" onkeydown="return false"/>
							<input type="number" name="min1" id="min1" max="'.$_SESSION['budget'].'" value="0" onkeydown="return false"/>';
						echo '<tr> <br>
							Αναζήτηση με βάση το μοντέλο: 
							<input name="model" type="text" value="" id="model" >
							<br>
							<input type="checkbox" name="phone" id="phone" value="phone"> phone<br>
							<input type="checkbox" name="tablet" id="tablet" value="tablet"> tablet<br>
							<input type="checkbox" name="mp3" id="mp3" value="mp3"> mp3<br>
							<input type="checkbox" name="mp4" id="mp4" value="mp4"> mp4<br>
		
							<button id="search">search</button><br>
							</form>';
					}
					else {
						echo '<form action="search.php" method="post">
						<div id="slider"> </div>
						<p>
						<label for="amount">Price range:</label>
						<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
						</p>
						<div id="slider-range"></div>
						<br>
						<input type="hidden" name="min1" id="min1" value="0"/>
						<input type="hidden" name="max1" id="max1" value="5000"/>
						<tr>
						Αναζήτηση με βάση το μοντέλο: 
						<input name="model" type="text" value="" id="model" >
						<br>
						<input type="checkbox" name="phone" id="phone" value="phone"> phone<br>
						<input type="checkbox" name="tablet" id="tablet" value="tablet"> tablet<br>
						<input type="checkbox" name="mp3" id="mp3" value="mp3"> mp3<br>
						<input type="checkbox" name="mp4" id="mp4" value="mp4"> mp4<br>
						<button id="search">search</button><br>
						</form>';
					}
				}
				else {
					echo '<form action="search.php" method="post">
						<div id="slider"> </div>
						<p>
						<label for="amount">Price range:</label>
						<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
						</p>
						<div id="slider-range"></div>
						<br>
						<input type="hidden" name="min1" id="min1" value="0"/>
						<input type="hidden" name="max1" id="max1" value="5000"/>
						<tr>
						Αναζήτηση με βάση το μοντέλο: 
						<input name="model" type="text" value="" id="model" >
						<br>
						<input type="checkbox" name="phone" id="phone" value="phone"> phone<br>
						<input type="checkbox" name="tablet" id="tablet" value="tablet"> tablet<br>
						<input type="checkbox" name="mp3" id="mp3" value="mp3"> mp3<br>
						<input type="checkbox" name="mp4" id="mp4" value="mp4"> mp4<br>
						<button id="search">search</button><br>
						</form>';
				}
			?>
		</div>
		<div class="col-sm-9">
			<form id="d" action="basket.php" method="post">
				<input name="lol2" id="lol2" onchange="run()"/>
				<button id="search" hidden>run</button><br>
			</form>
			<form id="p" action="del_pr.php" method="post">
				<input name="lol3" id="lol3" onchange="run()" />
				<button id="search" hidden>run</button><br>
			</form>			
			<?php
				$cat = $_SESSION["category"];
				if ($cat=="phone"){
					echo '<div class="row">
							<div class="col-sm-4"><img style="width:100%" src="data:image/jpeg;base64,'.base64_encode($_SESSION["photo"]).'"/></div>
							<div class="col-sm-6">
								<div class="row, row1"> Brand: ' . $_SESSION["brand"] . ' </div>
								<div class="row, row1"> Model: ' . $_SESSION["model"] . ' </div>
								<div class="row, row1"> Price: ' . $_SESSION["price"] . ' </div>
								<div class="row, row1"> First Camera: ' . $_SESSION["camera_primary"] . ' </div>
								<div class="row, row1"> Battery Capacity: ' . $_SESSION["battery_capacity"] . ' </div>
								<div class="row, row1"> Memory: ' . $_SESSION["internal_memory"] . ' </div>
								<div class="row, row1"> Color: ' . $_SESSION["color"] . ' </div>';
								echo'<div class="row, row1"> RAM: ' . $_SESSION["ram"] . ' </div>
								<div class="row, row1"> CPU: ' . $_SESSION["cpu"] . ' </div>
								<div class="row, row1"> Operational System: ' . $_SESSION["os"] . ' </div>
							</div>
							<div class="col-sm-2">';
								if (isset($_SESSION["email"])){
									if ($_SESSION['budget1']==1){
										$price2 = $_SESSION["price"];
										$budget2 = $_SESSION['budget'];
										if ($price2 > $budget2) {
											echo "Add more budget to buy it";
										}
										else {
											echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
										}
									}
									else {
										echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
									}
									if ($_SESSION["email"]=='ro@ot.com'){
										echo "<td> <div name='". $_SESSION["id_m"] . "' class='selecter2'><button id='but1' class='glyphicon glyphicon-remove'>Delete product</button></div></td>";
									} 									
								}
							echo '</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="row, row2"> Network: ' . $_SESSION["network"] . ' </div>
							<div class="row, row2"> Launch: ' . $_SESSION["launch"] . ' </div>
							<div class="row, row2"> Device Dimensions: ' . $_SESSION["device_dimensions"] . ' </div>
							<div class="row, row2"> Screen Dimensions: ' . $_SESSION["screen_dimensions"] . ' </div>';
							$ls= $_SESSION["loud_speaker"];
								if ($ls == 'y' || $ls == 'Y' ) {
									echo '<div class="row, row2"> Loud Speaker: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Loud Speaker: No </div>';
								}							
							$radio= $_SESSION["radio"];
								if ($radio == 'y' || $radio == 'Y' ) {
									echo '<div class="row, row2"> Radio: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Radio: No </div>';
								}
							$wlan= $_SESSION["wlan"];
								if ($wlan == 'y' || $wlan == 'Y') {
									echo '<div class="row, row2"> Wlan: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Wlan: No </div>';
								}
							$bluetooth= $_SESSION["bluetooth"];
								if ($bluetooth == 'y' || $bluetooth == 'Y') {
									echo '<div class="row, row2"> Bluetooth: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Bluetooth: No </div>';
								}
							$gps= $_SESSION["gps"];
								if ($gps == 'y' || $gps == 'Y') {
									echo '<div class="row, row2"> Gps: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Gps: No </div>';
								}
							
						echo '</div>	
						<div class="col-sm-6">';
							$mem_slot= $_SESSION["card_slot"];
								if ($mem_slot == 'y' || $mem_slot == 'Y') {
									echo '<div class="row, row2"> Card Slot: Yes </div>';
								}
								else {
									echo '<div class="row row2"> Card Slot: No </div>';
								}
						echo'<div class="row, row2"> Secondary Camera: ' . $_SESSION["camera_secondary"] . ' </div>
							<div class="row, row2"> Screen Pixels: ' . $_SESSION["screen_pixels"] . ' </div>
							<div class="row, row2"> Type of Sim: ' . $_SESSION["sim"] . ' </div>
							<div class="row, row2"> Number Of Sims: ' . $_SESSION["num_sim"] . ' </div>';
							$nfc= $_SESSION["nfc"];
								if ($nfc == 'y' || $nfc == 'Y') {
									echo '<div class="row, row2"> NFC: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> NFC: No </div>';
								}
							$wp= $_SESSION["water_proof"];
								if ($wp == 'y' || $wp == 'Y') {
									echo '<div class="row, row2"> WaterProof: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> WaterProof: No </div>';
								}
							$br= $_SESSION["battery_removable"];
								if ($br == 'y' || $br == 'Y') {
									echo '<div class="row, row2"> Battery Removable: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Battery Removable: No </div>';
								}
							$usb= $_SESSION["usb"];
								if ($usb == 'y' || $usb == 'Y') {
									echo '<div class="row, row2"> USB port: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> USB port: No </div>';
								}
					echo'</div>
					</div>';
				} 	
				else if ($cat== "tablet") {
					echo '<div class="row">
							<div class="col-sm-4"><img style="width:100%" src="data:image/jpeg;base64,'.base64_encode($_SESSION["photo"]).'"/></div>
							<div class="col-sm-6">
								<div class="row, row1"> Brand: ' . $_SESSION["brand"] . ' </div>
								<div class="row, row1"> Model: ' . $_SESSION["model"] . ' </div>
								<div class="row, row1"> Price: ' . $_SESSION["price"] . ' </div>
								<div class="row, row1"> First Camera: ' . $_SESSION["camera_primary"] . ' </div>
								<div class="row, row1"> Battery Capacity: ' . $_SESSION["battery_capacity"] . ' </div>
								<div class="row, row1"> Memory: ' . $_SESSION["internal_memory"] . ' </div>
								<div class="row, row1"> Color: ' . $_SESSION["color"] . ' </div>
								<div class="row, row1"> RAM: ' . $_SESSION["ram"] . ' </div>
								<div class="row, row1"> CPU: ' . $_SESSION["cpu"] . ' </div>
								<div class="row, row1"> Operational System: ' . $_SESSION["os"] . ' </div>
							</div>
							<div class="col-sm-2">';
								if (isset($_SESSION["email"])){
									if ($_SESSION['budget1']==1){
										$price2 = $_SESSION["price"];
										$budget2 = $_SESSION['budget'];
										if ($price2 > $budget2) {
											echo "Add more budget to buy it";
										}
										else {
											echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
										}
									}
									else {
										echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
									}
									if ($_SESSION["email"]=='ro@ot.com'){
										echo "<td> <div name='". $_SESSION["id_m"] . "' class='selecter2'><button id='but1' class='glyphicon glyphicon-remove'>Delete product</button></div></td>";
									} 								
								}
							echo '</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="row, row2"> Network: ' . $_SESSION["network"] . ' </div>
							<div class="row, row2"> Launch: ' . $_SESSION["launch"] . ' </div>
							<div class="row, row2"> Device Dimensions: ' . $_SESSION["device_dimensions"] . ' </div>
							<div class="row, row2"> Screen Dimensions: ' . $_SESSION["screen_dimensions"] . ' </div>';
							$ls= $_SESSION["loud_speaker"];
								if ($ls == 'y' || $ls == 'Y' ) {
									echo '<div class="row, row2"> Loud Speaker: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Loud Speaker: No </div>';
								}							
							$radio= $_SESSION["radio"];
								if ($radio == 'y' || $radio == 'Y' ) {
									echo '<div class="row, row2"> Radio: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Radio: No </div>';
								}
							$wlan= $_SESSION["wlan"];
								if ($wlan == 'y' || $wlan == 'Y') {
									echo '<div class="row, row2"> Wlan: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Wlan: No </div>';
								}
							$bluetooth= $_SESSION["bluetooth"];
								if ($bluetooth == 'y' || $bluetooth == 'Y') {
									echo '<div class="row, row2"> Bluetooth: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Bluetooth: No </div>';
								}
							$gps= $_SESSION["gps"];
								if ($gps == 'y' || $gps == 'Y') {
									echo '<div class="row, row2"> Gps: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Gps: No </div>';
								}
							
						echo '</div>	
						<div class="col-sm-6">';
							$mem_slot= $_SESSION["card_slot"];
								if ($mem_slot == 'y' || $mem_slot == 'Y') {
									echo '<div class="row, row2"> Card Slot: Yes </div>';
								}
								else {
									echo '<div class="row row2"> Card Slot: No </div>';
								}
						echo'<div class="row, row2"> Secondary Camera: ' . $_SESSION["camera_secondary"] . ' </div>
							<div class="row, row2"> Screen Pixels: ' . $_SESSION["screen_pixels"] . ' </div>
							<div class="row, row2"> Type of Sim: ' . $_SESSION["sim"] . ' </div>
							<div class="row, row2"> Number Of Sims: ' . $_SESSION["num_sim"] . ' </div>';
							$nfc= $_SESSION["nfc"];
								if ($nfc == 'y' || $nfc == 'Y') {
									echo '<div class="row, row2"> NFC: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> NFC: No </div>';
								}
							$wp= $_SESSION["water_proof"];
								if ($wp == 'y' || $wp == 'Y') {
									echo '<div class="row, row2"> WaterProof: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> WaterProof: No </div>';
								}
							$br= $_SESSION["battery_removable"];
								if ($br == 'y' || $br == 'Y') {
									echo '<div class="row, row2"> Battery Removable: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Battery Removable: No </div>';
								}
							$usb= $_SESSION["usb"];
								if ($usb == 'y' || $usb == 'Y') {
									echo '<div class="row, row2"> USB port: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> USB port: No </div>';
								}
					echo'</div>
					</div>';
				}
				else if ($cat == "mp3") {
					echo '<div class="row">
							<div class="col-sm-4"><img style="width:100%" src="data:image/jpeg;base64,'.base64_encode($_SESSION["photo"]).'"/></div>
							<div class="col-sm-6">
								<div class="row, row1"> Brand: ' . $_SESSION["brand"] . ' </div>
								<div class="row, row1"> Model: ' . $_SESSION["model"] . ' </div>
								<div class="row, row1"> Price: ' . $_SESSION["price"] . ' </div>
								<div class="row, row1"> Battery Capacity: ' . $_SESSION["battery_capacity"] . ' </div>
								<div class="row, row1"> Memory: ' . $_SESSION["internal_memory"] . ' </div>
								<div class="row, row1"> Color: ' . $_SESSION["color"] . ' </div>
							</div>
							<div class="col-sm-2">';
								if (isset($_SESSION["email"])){
									if ($_SESSION['budget1']==1){
										$price2 = $_SESSION["price"];
										$budget2 = $_SESSION['budget'];
										if ($price2 > $budget2) {
											echo "Add more budget to buy it";
										}
										else {
											echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
										}
									}
									else {
										echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
									}
									if ($_SESSION["email"]=='ro@ot.com'){
										echo "<td> <div name='". $_SESSION["id_m"] . "' class='selecter2'><button id='but1' class='glyphicon glyphicon-remove'>Delete product</button></div></td>";
									} 								
								}
							echo '</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="row, row2"> Launch: ' . $_SESSION["launch"] . ' </div>
							<div class="row, row2"> Device Dimensions: ' . $_SESSION["device_dimensions"] . ' </div>
							<div class="row, row2"> Screen Dimensions: ' . $_SESSION["screen_dimensions"] . ' </div>';
							$ls= $_SESSION["loud_speaker"];
								if ($ls == 'y' || $ls == 'Y' ) {
									echo '<div class="row, row2"> Loud Speaker: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Loud Speaker: No </div>';
								}							
							$radio= $_SESSION["radio"];
								if ($radio == 'y' || $radio == 'Y' ) {
									echo '<div class="row, row2"> Radio: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Radio: No </div>';
								}
						echo '</div>	
						<div class="col-sm-6">';
							$mem_slot= $_SESSION["card_slot"];
								if ($mem_slot == 'y' || $mem_slot == 'Y') {
									echo '<div class="row, row2"> Card Slot: Yes </div>';
								}
								else {
									echo '<div class="row row2"> Card Slot: No </div>';
								}
						echo'
							<div class="row, row2"> Screen Pixels: ' . $_SESSION["screen_pixels"] . ' </div>';
							$wp= $_SESSION["water_proof"];
								if ($wp == 'y' || $wp == 'Y') {
									echo '<div class="row, row2"> WaterProof: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> WaterProof: No </div>';
								}
							$usb= $_SESSION["usb"];
								if ($usb == 'y' || $usb == 'Y') {
									echo '<div class="row, row2"> USB port: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> USB port: No </div>';
								}
					echo'</div>
					</div>';
				}
				else  {
					echo '<div class="row">
							<div class="col-sm-4"><img style="width:100%" src="data:image/jpeg;base64,'.base64_encode($_SESSION["photo"]).'"/></div>
							<div class="col-sm-6">
								<div class="row, row1"> Brand: ' . $_SESSION["brand"] . ' </div>
								<div class="row, row1"> Model: ' . $_SESSION["model"] . ' </div>
								<div class="row, row1"> Price: ' . $_SESSION["price"] . ' </div>
								<div class="row, row1"> First Camera: ' . $_SESSION["camera_primary"] . ' </div>
								<div class="row, row1"> Battery Capacity: ' . $_SESSION["battery_capacity"] . ' </div>
								<div class="row, row1"> Memory: ' . $_SESSION["internal_memory"] . ' </div>
								<div class="row, row1"> Color: ' . $_SESSION["color"] . ' </div>
							</div>
							<div class="col-sm-2">';
								if (isset($_SESSION["email"])){
									if ($_SESSION['budget1']==1){
										$price2 = $_SESSION["price"];
										$budget2 = $_SESSION['budget'];
										if ($price2 > $budget2) {
											echo "Add more budget to buy it";
										}
										else {
											echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
										}
									}
									else {
										echo "<div name='". $_SESSION["id_m"] . "' class='selecter1'><button id='but1' class='glyphicon glyphicon-shopping-cart'>Add To Cart</button></div>";
									}
									if ($_SESSION["email"]=='ro@ot.com'){
										echo "<td> <div name='". $_SESSION["id_m"] . "' class='selecter2'><button id='but1' class='glyphicon glyphicon-remove'>Delete product</button></div></td>";
									} 								
								}
							echo '</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="row, row2"> Launch: ' . $_SESSION["launch"] . ' </div>
							<div class="row, row2"> Device Dimensions: ' . $_SESSION["device_dimensions"] . ' </div>
							<div class="row, row2"> Screen Dimensions: ' . $_SESSION["screen_dimensions"] . ' </div>';
							$ls= $_SESSION["loud_speaker"];
								if ($ls == 'y' || $ls == 'Y' ) {
									echo '<div class="row, row2"> Loud Speaker: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Loud Speaker: No </div>';
								}							
							$radio= $_SESSION["radio"];
								if ($radio == 'y' || $radio == 'Y' ) {
									echo '<div class="row, row2"> Radio: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Radio: No </div>';
								}
							$bluetooth= $_SESSION["bluetooth"];
								if ($bluetooth == 'y' || $bluetooth == 'Y') {
									echo '<div class="row, row2"> Bluetooth: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> Bluetooth: No </div>';
								}
						echo '</div>	
						<div class="col-sm-6">';
							$mem_slot= $_SESSION["card_slot"];
								if ($mem_slot == 'y' || $mem_slot == 'Y') {
									echo '<div class="row, row2"> Card Slot: Yes </div>';
								}
								else {
									echo '<div class="row row2"> Card Slot: No </div>';
								}
						echo'<div class="row, row2"> Secondary Camera: ' . $_SESSION["camera_secondary"] . ' </div>
							<div class="row, row2"> Screen Pixels: ' . $_SESSION["screen_pixels"] . ' </div>';
							$wp= $_SESSION["water_proof"];
								if ($wp == 'y' || $wp == 'Y') {
									echo '<div class="row, row2"> WaterProof: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> WaterProof: No </div>';
								}
							$usb= $_SESSION["usb"];
								if ($usb == 'y' || $usb == 'Y') {
									echo '<div class="row, row2"> USB port: Yes </div>';
								}
								else {
									echo '<div class="row, row2"> USB port: No </div>';
								}
						echo'</div>
					</div>';					
				}
			?>
		</div>
	</div>
</div>

<br><br><br><br>

<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>