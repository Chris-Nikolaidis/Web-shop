<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST"){
	$qu1=$_POST['q1'];
	$qu2=$_POST['q2'];
	$qu3=$_POST['q3'];
	if (strlen($_POST['q4'])!=0){
		$qu4=$_POST['q4'];
	}
	else{
		$qu4='e';
	}
}
$sql = "SELECT * FROM feedback";
$result = $connect->query($sql);
$c=$result->num_rows;
$c++;
$id1=$c;
	
if (isset($_SESSION["id"])){		
	$cd=$_SESSION["id"];
	//xreiazomaste to consumer_id mesw session
	$sql="INSERT into feedback (id,q1,q2,q3,q4,consumer_id) VALUES('".$id1."','".$qu1."','".$qu2."','".$qu3."','".$qu4."','".$cd."')";
	$result = $connect->query($sql);
	header( "refresh:3; url=feedback.php" );
	echo "Σας ευχαριστούμε. Η γνώμη σας μας είναι πολύτιμη.";
}
?> 