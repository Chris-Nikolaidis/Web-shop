<?php
	session_start();
	include 'config.php';

	$a = $_POST['lol'];

	$query = "SELECT * FROM products WHERE id = '$a' LIMIT 0,1";
	$result = $connect->query($query);
	
	while ($row = $result->fetch_row()){
	$_SESSION["id_m"]= $row[0];
    $_SESSION["model"] = $row[1];
    $_SESSION["brand"] = $row[2];
    $_SESSION["category"] = $row[3];
    $_SESSION["network"] = $row[4];
    $_SESSION["launch"] = $row[5];
	$_SESSION["device_dimensions"] = $row[6];
    $_SESSION["screen_dimensions"] = $row[7];
    $_SESSION["screen_pixels"] = $row[8];
    $_SESSION["sim"] = $row[9];
    $_SESSION["num_sim"] = $row[10];
    $_SESSION["os"] = $row[11];
    $_SESSION["cpu"] = $row[12];
    $_SESSION["ram"] = $row[13];
    $_SESSION["card_slot"] = $row[14];
    $_SESSION["internal_memory"] = $row[15];
    $_SESSION["camera_primary"] = $row[16];
    $_SESSION["camera_secondary"] = $row[17];
    $_SESSION["radio"] = $row[18];
    $_SESSION["wlan"] = $row[19];
    $_SESSION["bluetooth"] = $row[20];
    $_SESSION["gps"] = $row[21];
    $_SESSION["nfc"] = $row[22];
    $_SESSION["water_proof"] = $row[23];
    $_SESSION["battery_capacity"] = $row[24];
    $_SESSION["battery_removable"] = $row[25];
    $_SESSION["color"] = $row[26];
    $_SESSION["loud_speaker"] = $row[27];
    $_SESSION["usb"] = $row[28];
    $_SESSION["price"] = $row[29];
    $_SESSION["photo"] = $row[30];
	}	
	header('Location: http://localhost/kinita/showcase.php');	
?>