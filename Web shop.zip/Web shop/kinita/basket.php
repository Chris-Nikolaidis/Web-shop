<?php
include 'config.php';
session_start();

$a = $_POST['lol2'];
echo "product id";
echo $a;

$b_id =$_SESSION["basket_id"];
echo "basket id";
echo $b_id;
$pr_id = $a;
$status =0;

$query2 = "SELECT * FROM orders WHERE basket_id= '$b_id' AND products_id = '$pr_id'";
$result2 = $connect->query($query2);
if($result2->num_rows > 0 ){
	while ($row = $result2->fetch_row()){
		$pr_num= $row[3];
	}
	$pr_num = $pr_num + 1;
	$sql1="UPDATE orders SET pr_num= '$pr_num' WHERE basket_id= '$b_id' AND products_id = '$pr_id'";
	$result = $connect->query($sql1);	
} 
else {
	$i = "SELECT * FROM orders ORDER BY no DESC LIMIT 1";
	$i1 = $connect->query($i);
	while ($row = $i1->fetch_row()){
		$c= $row[0];
	}
	$c= $c+1;
	$no=$c;
	$sql="INSERT into orders (no,basket_id,products_id,pr_num,status) VALUES('".$no."','".$b_id."','".$pr_id."','1','0')";
	$result = $connect->query($sql);
}	

$sql4 ="SELECT * FROM products WHERE id='$pr_id'";
$result4 = $connect->query($sql4);
while ($row = $result4->fetch_row()){
	$price= $row[29];
	echo "price";
	echo $price;
}

if (isset($_SESSION['budget1'])){
	if ($_SESSION['budget1']== 1){
		$sql3 = "SELECT * FROM basket WHERE id='$b_id'";
		$result3 = $connect->query($sql3);
		while ($row = $result3->fetch_row()){
			$budget= $row[3];
			echo "budget";
			echo $budget;
		}
		$budget = $budget - $price;
		echo "new budget";
		echo $budget;
		$sql5 = "UPDATE basket SET budget='$budget' WHERE id='$b_id'";
		$result5 = $connect->query($sql5);
		$_SESSION['budget']=$budget;
	}
}

$sql6= "SELECT * FROM basket WHERE id='$b_id'";
$result6 = $connect->query($sql6);
while ($row = $result6->fetch_row()){
	$total_price= $row[2];
	echo "total_price";
	echo $total_price;
}
$total_price = $total_price + $price;
echo "new total_price";
echo $total_price;
$sql7 = "UPDATE basket SET total_price='$total_price' WHERE id='$b_id'";
$result7 = $connect->query($sql7);

if ($_SESSION['budget1']==1){
	if ($budget < 1) {
		$_SESSION['budget2'] = 0;
	}
}

header('Location: http://localhost/kinita/basket_res.php');
?>