<?php
	session_start();
	include 'config.php';
	
	$pr_id = $_POST['lol3'];
	
	$sql3 = "SELECT * FROM products WHERE id = '$pr_id'";
	$result3 = $connect->query($sql3);
	if($result3->num_rows > 0 ){
		while ($row = $result3->fetch_row()){
			$price = $row[29];
		}
	}
	
	$sql = "SELECT * FROM orders WHERE products_id = '$pr_id'";
	$result = $connect->query($sql);
	if($result->num_rows > 0 ){
		while ($row = $result->fetch_row()){
			$b_id= $row[1];
			$pr_num = $row[3];
			$sql2 = "SELECT * FROM basket WHERE id='$b_id'";
			$result2 = $connect->query($sql2);
			if($result2->num_rows > 0 ){
				while ($row = $result2->fetch_row()){
					$total_price = $row[2];
				}
			}
			$gain = $price * $pr_num; 
			$total_price = $total_price - $gain;
			echo $total_price;
			
			$sql4="UPDATE basket SET total_price= '$total_price' WHERE id= '$b_id'";
			$result4 = $connect->query($sql4);
			
			$sql5= "DELETE FROM orders WHERE products_id='$pr_id'";
			$result5 = $connect->query($sql5);
			
		}
	}
	$sql6= "DELETE FROM products WHERE id='$pr_id'";
	$result6 = $connect->query($sql6);	
	
	header('Location: http://localhost/kinita/products.php');
?>

