<!DOCTYPE html>
<html lang="en">
<?php
	session_start();
	include 'config.php';
	
?>
<head>
	
<!-- bootstrap- style -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<!-- my additions -->  
<script type="text/javascript" src="java.js"></script>
<link rel="stylesheet" type="text/css" href="layout.css">

<!-- carousel script -->
<script>
	function carousel() {
	var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 3500);
	}
</script>

<style>
#here {
	min-height: 100%;
}
</style>
</head>
<body>
	
<div class="container text-center">
    <h2>TechHub, the future is here.</h2>
	<p> Τα πάντα για κινητά, tablet <br> 
		mp3-mp4 & accessories
	</p>
</div>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="homepage.php">TechHub</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
			<li class="active"><a href="#">Home</a></li>
			<li><a href="products.php">Products</a></li>
			<li><a href="contact.php">Contact</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<?php
				if (!isset($_SESSION["email"])){
					echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Είσοδος</a></li>
						  <li><a href="signup.php"><span class="glyphicon glyphicon-pencil"></span> Εγγραφή</a></li>';
				}
				if (isset($_SESSION['email'])){
					if($_SESSION['email']=='ro@ot.com'){	
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile Root </a></li>
							  <li class="active"><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="newProduct.php"><span class="glyphicon glyphicon-plus"></span> Εισαγωγή νεόυ προϊόντος</a></li>	  
							  <li><a href="vfeedback.php"><span class="glyphicon glyphicon-tower"></span> View Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>';
					}
					else{
						echo '<li><a href="editprofile.php"><span class="glyphicon glyphicon-user"></span> Profile </a></li>
							  <li class="active"><a href="basket_res.php"><span class="glyphicon glyphicon-shopping-cart"></span> Καλάθι αγορών</a></li>
						      <li><a href="feedback.php"><span class="glyphicon glyphicon-tower"></span> Feedback</a></li>
							  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>'; 
					} 
				}
			?>
			</ul>
		</div>
	</div>
</nav>
<div class="container" id="here">    
	<div class="row">
		<div class="col-sm-3">
			<div class="products1" >
				<img class="mySlides" id="car1" style='width:100%' src="photo/phone2.jpg">
				<img class="mySlides" id="car2" style='width:100%' src="photo/tablet.jpg">	
				<img class="mySlides" id="car3" style='width:100%' src="photo/1.jpg">		
				<img class="mySlides" id="car4" style='width:100%' src="photo/2.jpg">
				<img class="mySlides" id="car5" style='width:100%' src="photo/4.jpg">
				<img class="mySlides" id="car6" style='width:100%' src="photo/6.jpg">
				<img class="mySlides" id="car7" style='width:100%' src="photo/7.jpg">
				<img class="mySlides" id="car8" style='width:100%' src="photo/8.jpg">
				<img class="mySlides" id="car9" style='width:100%' src="photo/13.jpg">
				<img class="mySlides" id="car10" style='width:100%' src="photo/15.jpg">								
			</div>
			<script>
				var myIndex = 0;
				carousel();
			</script>
		</div>
		<div class="col-sm-9" >
			<?php
				$a=$_POST['money'];
				$c_id = $_SESSION["id"];
				if ($_SESSION['address1']==1){
					$address = $_POST['address'];
					$c_address="UPDATE consumer SET address='$address' WHERE id='$c_id'";
					$ad=  $connect->query($c_address);
					$_SESSION["address"]= $address;
				}
				//echo $a;
				//echo $address;
				if (($a == "credit") && ($_SESSION["credit_card"]=='0')){
					echo '<form action="fin2.php" id="qw2" method="post" align="center">';
						echo 'Card number <input name="card_num" type="number" id="card_num" required>
							<button id="end">Υποβολή</button>';
					echo "</form>";
				}
				else {
					echo "Η παραγγελία σας ετοιμάζεται για αποστολή. Σας ευχαριστούμε για την προτίμησή σας.";
					$c_id=$_SESSION["id"];
					$b_id=$_SESSION["basket_id"];
					$cost=$_SESSION['t1'];
					$pr_ex="SELECT * FROM consumer WHERE id='$c_id'";
					$pr_res=$connect->query($pr_ex);
					if($pr_res->num_rows > 0){
						while ($row = $pr_res->fetch_assoc()){
							$cost=$cost+$row['expenses'];
						}		
					}
					$c_expesnes="UPDATE consumer SET expenses='$cost' WHERE id='$c_id'";
					$c_status="DELETE FROM orders WHERE basket_id='$b_id'";
					$c_total="UPDATE basket SET total_price='0' WHERE consumer_id='$c_id'";
					$ex=  $connect->query($c_expesnes);
					$st= $connect->query($c_status);
					$tot= $connect->query($c_total);
					
					$budget = 5000;
					$_SESSION['budget1']=0;
					$_SESSION['budget2']=1;
					$sql = "UPDATE basket SET budget='$budget' WHERE consumer_id='$c_id'";
					$result = $connect->query($sql);
				}
			?>
		</div>
	</div>
</div>

<br><br><br><br>
			
<footer class="container-fluid text-center">
	<p>Online Store Copyright:    © 2018 TechHub.com All Rights Reserved   </p>
	<br>
	<a href="contact.php"> <p> Privacy Policy & Terms and Conditions  </p>  </a>
</footer>

</body>
</html>