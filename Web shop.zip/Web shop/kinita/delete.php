<?php
include 'config.php';
session_start();

$pr_id = $_POST['d2'];
echo $pr_id;

$b_id =$_SESSION["basket_id"];
echo $b_id;

$sql = "SELECT * FROM orders WHERE basket_id= '$b_id' AND products_id = '$pr_id'";
$result = $connect->query($sql);
if($result->num_rows > 0 ){
	while ($row = $result->fetch_row()){
		$pr_num= $row[3];
	}
}
$sql2 = "SELECT * FROM products WHERE id= '$pr_id'";
$result2 = $connect->query($sql2);
if($result2->num_rows > 0 ){
	while ($row = $result2->fetch_row()){
		$price= $row[29];
	}
}

$gain = $price * $pr_num;


if (isset($_SESSION['budget1'])){
	if ($_SESSION['budget1']== 1){
		$sql3 = "SELECT * FROM basket WHERE id='$b_id'";
		$result3 = $connect->query($sql3);
		while ($row = $result3->fetch_row()){
			$budget= $row[3];
			echo "budget";
			echo $budget;
		}
		$budget = $budget + $gain;
		echo "new budget";
		echo $budget;
		$sql4 = "UPDATE basket SET budget='$budget' WHERE id='$b_id'";
		$result4 = $connect->query($sql4);
		$_SESSION['budget']=$budget;
	}
}

$sql5= "SELECT * FROM basket WHERE id='$b_id'";
$result5 = $connect->query($sql5);
while ($row = $result5->fetch_row()){
	$total_price= $row[2];
	echo "total_price";
	echo $total_price;
}
$total_price = $total_price - $gain;
echo "new total_price";
echo $total_price;
$sql6 = "UPDATE basket SET total_price='$total_price' WHERE id='$b_id'";
$result6 = $connect->query($sql6);

if ($_SESSION['budget1']==1){
	if ($budget > 1) {
		$_SESSION['budget2'] = 1;
	}
}

$sql7="DELETE FROM orders WHERE basket_id='$b_id' AND products_id = '$pr_id'";
$result7 = $connect->query($sql7);

header('Location: http://localhost/kinita/basket_res.php');

?>